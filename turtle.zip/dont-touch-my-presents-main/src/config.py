class Config:
    FPS = 60

    # Screen Information
    WIDTH = 360
    HEIGHT = 640

    # Movement
    ACC = 1.2
    FRIC = -0.10
