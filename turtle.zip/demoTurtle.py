import tkinter as tk
import turtle as t

def do_stuff():
    for color in ["red","yellow","green"]:
        turtle.color(color)
        turtle.right(120)

def press():
    do_stuff()

if __name__ == "__main__":
    screen = t.Screen()
    screen.bgcolor("cyan")
    canvas = screen.getcanvas()
    button = tk.Button(canvas.master,text = "Press me",command = press)
    canvas.create_window(-200,-200,window = button)
    turtle = t.Turtle(shape = "turtle")
