class ContactImportForm(forms.Form):
    headers = ["lastname","firstname","email"]
    file = forms.FileField(label='Select your CSV File',validators=[CsvFileValidator(headers)])
    
    def clean_file(self):
        file = self.cleaned_data['file']
        return file    
