import os

#----------------import Game Files----------------
#Game 1
def canon():
    os.system("Canon")

#Game 2
def Bird():
    os.system("Flappy_Bird")

#Game 3
def FootBall():
    os.system("FootBall")

#Game 4
def Iron():
    os.system("IronMan")

#Game 5
def Snake():
    os.system("Snake")

#Game 6
def Alien():
    os.system("Space_Invader")

#Game 7
def Race():
    os.system("Turtle_Race")

#Game 8
def TicTacToe():
    os.system("TicTacToe")

#Game 9
def RPS():
    os.system("RockPaperScissor")

#Game 10
def Ball():
    os.system("Balancing_Ball")

#Game 11
def Ludo():
    os.system("Ludo")

#Game 12
def Battle():
    os.system("battle")

#Game 13
def Archery():
    os.system("archery")

#Game 14
def SnakesNLadders():
    os.system("Snakes_N_Ladders_Game")

#Game 15
def CarRace():
    os.system("Car_Race")

#Game 16
def Quiz():
    os.system("Quiz")

#Game 17
def Checkers():
    os.system("Checkers")

#Game 18
def Fighting():
    os.system("Fighting")

#Game 19
def Mario():
    os.system("SuperMario")

#Game 20
def Pacman():
    os.system("pacman")

#Game 21
def ArcDash():
    os.system("ArcDash")

#Game 22
def Puzzle():
    os.system("Puzzle")

#Game 23
def Pool():
    os.system("Pool")

#Game 24
def Carrom():
    os.system("Carrom")

#Game 25
def Present():
    os.system("Present")
