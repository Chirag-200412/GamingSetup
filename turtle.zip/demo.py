import turtle as t
import random as r
win = t.getscreen()
robot = t.Turtle()

'''def up():
    robot.fd(100)

def down():
    robot.bk(100)

def left():
    robot.lt(90)

def right():
    robot.rt(90)

win.listen()
win.onkeypress(up,'Up')
win.onkey(down,'Down')
win.onkeyrelease(left,'Left')
win.onkey(right,'Right')

def fig():
    for i in range(6):
        robot.lt(60)
        robot.fd(50)
win.onkey(fig,'h')

def fig1():
    robot.begin_fill()
    robot.circle(50)
    robot.end_fill()
win.onkey(fig1,'c')
    
def cln():
    robot.clear()

win.onclick(cln,'c')
'''

'''t.hideturtle()

def drag(x,y):
    robot.ondrag(None)
    robot.seth(robot.towards(x,y))
    robot.goto(x,y)
    robot.ondrag(drag)
win.listen()

def move(x,y):
    robot.up()
    robot.goto(x,y)
    robot.down()

def main():
    robot.ondrag(drag)
    win.onclick(move)
main()
'''

'''def keys():
    win.listen()
    win.onkey(lambda:robot.fd(100),'Up')
    win.onkey(lambda:robot.bk(100),'Down')
    win.onkey(lambda:robot.lt(90),'Left')
    win.onkey(lambda:robot.rt(90),'Right')
keys()
'''

list1 = ['red','grey','black','brown','green']
#win.tracer(10,100)

#robot.speed(0)
'''def circle():
    robot.circle(100)
    r.shuffle(list1)
    robot.color(list1[0])
        
def pattern():
    for i in range(50):
        circle()
        robot.rt(10)
win.update()
pattern()
'''

'''def pattern1():
    for i in range(2):
        robot.lt(90)
        robot.circle(50,90)
pattern1()
'''

'''robot.ht()
def patels(r1,a):
    for i in range(2):
        r.shuffle(list1)
        robot.color(list1[0])
        robot.begin_fill()
        robot.circle(r1,a)
        robot.lt(180-a)
        robot.end_fill()
        
def flower(n,r1,a):
    for i in range(n):
        patels(r1,a)
        robot.lt(360/n)
flower(6,60,60)
'''

'''def pattern3():
    for i in range(6):
        for j in range(4):
            r.shuffle(list1)
            robot.color(list1[0])
            robot.circle(100,steps = 6)
            robot.rt(100)
pattern3()
'''
'''def design():
    win.resetscreen()
    robot.speed(0)
    while True:
        for i in range(50):
            r.shuffle(list1)
            robot.color(list1[0])
            for j in range(4):
                robot.fd(100)
                robot.lt(90)
            robot.rt(10)
design()
'''
'''def design2():
    robot.speed(0)
    robot.ht()
    for i in range(50):
        r.shuffle(list1)
        robot.color(list1[0])
        robot.circle(5*i)
        robot.circle(-5*i)
        robot.lt(i)
design2()
'''
'''def design3():
    robot.speed(0)
    robot.ht()
    while True:
        for i in range(200):
            r.shuffle(list1)
            robot.color(list1[0])
            robot.width(i/50)
            robot.fd(i)
            robot.lt(59)
        robot.up()
        robot.home()
        robot.down()
design3()
'''
'''def design4():
    robot.speed(0)
    #robot.ht()
    while True:
        for i in range(12):
            r.shuffle(list1)
            robot.color(list1[0])
            robot.begin_fill()
            robot.rt(90)
            robot.fd(200)
            robot.lt(120)
            robot.fd(200)
            robot.lt(120)
            robot.fd(200)
            robot.end_fill()
            robot.fd(200)
design4()
'''
'''def design5():
    robot.speed(0)
    robot.up()
    robot.goto(100,80)
    robot.down()
    for i in range(100):
        r.shuffle(list1)
        robot.color(list1[0])
        robot.rt(182)
        robot.fd(400)
design5()
'''
'''def design6():
    robot.speed(0)
    robot.up()
    robot.goto(100,80)
    robot.down()
    for i in range(50):
        r.shuffle(list1)
        robot.color(list1[0])
        robot.begin_fill()
        robot.circle(60,360)
        robot.end_fill()
        robot.lt(120)
        robot.circle(120,300)
        robot.circle(150)
design6()
'''
'''def design7():
    robot.speed(0)
    for i in range(0,10):
        x = 0
        y = 1
        z = 0
        r.shuffle(list1)
        for j in range(4):
            x = 0
            y = 1
            z = 0
            robot.color(list1[0])
            robot.begin_fill()
            for k in range(0,11):
                robot.circle(y,90)
                z = x+y
                x = y
                y = z
                robot.goto(0,0)
                robot.end_fill()
                robot.rt(80)
design7()
'''

#Click and drag Projects
'''
def Mouse_Event1():
    #win.resetscreen()
    robot.speed(0)
    def work1(x,y):
        robot.up()
        robot.goto(x,y)
        robot.down()
        robot.color("green")
        robot.begin_fill()
        for i in range(4):
            robot.fd(100)
            robot.lt(90)
        robot.end_fill()
    def work2(x,y):
        robot.up()
        robot.goto(x,y)
        robot.down()
        robot.begin_fill()
        for i in range(5):
            robot.lt(144)
            robot.fd(100)
        robot.end_fill()
    win.onclick(work1)
    win.onclick(work2,btn=3)
Mouse_Event1()
'''
'''def Mouse_Event2():
    robot.speed(0)
    def spiral1(x,y):
        robot.up()
        robot.goto(x,y)
        robot.down()
        for i in range(100):
            r.shuffle(list1)
            robot.color(list1[0])
            robot.fd(i+1)
            robot.rt(90)
    def spiral2(x,y):
        robot.up()
        robot.goto(x,y)
        robot.down()
        a = 100
        for i in range(100):
            robot.color('Blue')   
            robot.fd(a)
            robot.rt(144)
            a-=2
    win.onclick(spiral1)
    win.onclick(spiral2,btn=3)
Mouse_Event2()
'''
'''def key_events():
    robot.color(list1[0])
    win.onkey(lambda:robot.fd(100),'Up')
    win.onkey(lambda:robot.lt(90),'Left')
    win.onkey(lambda:robot.bk(100),'Down')
    win.onkey(lambda:robot.rt(90),'Right')
    win.listen()

def move(x,y):
    robot.up()
    robot.goto(x,y)
    robot.down()

def cln(x,y):
    robot.clear()

def operate():
    key_events()
    win.onclick(cln,btn=3)
    win.onclick(move)
operate()
'''

#creating star pattern
'''def star(x,y):
    #win.resetscreen()
    while True:
        n = 30
        x = 144
        for i in range(n):
            r.shuffle(list1)
            robot.speed(0)
            robot.color(list1[0],list1[1])
            robot.begin_fill()
            for j in range(5):
                robot.fd(5*n-5*i)
                robot.rt(x)
                robot.fd(5*n-5*i)
                robot.rt(72-x)
            robot.end_fill()
            robot.rt(144)

def fill_clean(x,y):
    robot.clear()
    robot.reset()

def invoke():
    win.onclick(star)
    win.onclick(fill_clean,btn=3)
invoke()
'''
'''def star(x,y):
    #win.resetscreen()
    win.tracer(10,10)
    while True:
        n = 30
        x = 144
        for i in range(n):
            r.shuffle(list1)
            robot.speed(0)
            robot.color(list1[0],list1[1])
            robot.begin_fill()
            for j in range(5):
                robot.fd(5*n-5*i)
                robot.rt(x)
                robot.fd(5*n-5*i)
                robot.rt(72-x)
            robot.end_fill()
            robot.rt(144)

def fill_clean(x,y):
    robot.clear()
    robot.reset()

def invoke1():
    win.onclick(star)
    win.onclick(fill_clean,btn=3)
invoke1()
'''

#dragging
'''def dragging(x,y):
    robot.ondrag(None)
    robot.seth(t.towards(x,y))
    robot.goto(x,y)
    robot.ondrag(dragging)

def cln(x,y):
    robot.clear()

def move1(x,y):
    robot.up()
    robot.goto(x,y)
    robot.down()

def start_drag():
    #win.resetscreen()
    win.listen()
    robot.color('red')
    robot.ondrag(dragging)
    win.onclick(cln,btn=3)
    win.onclick(move1)
    win.mainloop()
start_drag()
'''
'''def rainbow_spiral():
    #win.resetscreen()
    while True:
        win.tracer(30)
        for i in range(500):
            r.shuffle(list1)
            robot.color(list1[0])
            robot.speed(0)
            robot.fd(5+i)
            robot.rt(91)
        robot.up()
        robot.home()
        robot.down()

def circular_spiral():
    #win.resetscreen()
    while True:
        z = 150
        win.tracer(30)
        for x in range(7):
            r.shuffle(list1)
            robot.speed(0)
            robot.color(list1[0])
            for i in range(z):
                robot.circle(i)
                robot.rt(90)
            z-=20
circular_spiral()
'''
