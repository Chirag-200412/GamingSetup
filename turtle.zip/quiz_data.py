quiz_data = [
    {
        "question": "What is the capital of France?",
        "choices": ["Paris", "London", "Berlin", "Madrid"],
        "answer": "Paris"
    },
    {
        "question": "What is the largest planet in our solar system?",
        "choices": ["Jupiter", "Saturn", "Mars", "Earth"],
        "answer": "Jupiter"
    },
    {
        "question": "What is the chemical symbol for gold?",
        "choices": ["Go", "Au", "Ag", "Gd"],
        "answer": "Au"
    },
    {
        "question": "Which country is known as the 'Land of the Rising Sun'?",
        "choices": ["China", "Japan", "South Korea", "Thailand"],
        "answer": "Japan"
    },
    {
        "question": "Who is the president of South Korea?",
        "choices": ["Xi Jinping", "Shinzo Abe", "Kim Jong Un", "Yoon Suk Yeol"],
        "answer": "Yoon Suk Yeol"
    },
    {
        "question": "In which month there is 28 days?",
        "choices": ["January", "February", "March", "All of Mentioned"],
        "answer": "All of Mentioned"
    }
]
