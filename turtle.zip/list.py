l = {'c','y','a','v'}
print(l)
