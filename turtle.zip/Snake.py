import turtle
import time
import random
from turtle import TurtleScreen,RawTurtle
import tkinter as tk
import winsound

win = tk.Tk()
win.geometry("900x700")
win.resizable(width = False,height = False)
win.title("----Snake----")
win["bg"] = "#180833"

def start():
    canvas = tk.Canvas(win,width = 850,height = 600,bg = "black")
    canvas.place(x = 25,y = 10)

    delay = 0.1
    score = 0
    high_score = 0

    #set up the screen
    wn = TurtleScreen(canvas)
    wn.register_shape("SnakeImage/Strawberry_2.gif")
    wn.register_shape("SnakeImage/Snake.gif")
    wn.bgcolor("green")
    wn.width = 840
    wn.height = 600
    wn.tracer(0)

    #Snake Head
    head = RawTurtle(wn)
    head.shape("SnakeImage/Snake.gif")
    head.speed(0)
    head.penup()
    head.goto(0,0)
    head.direction = "stop"

    #Snake Food
    food = RawTurtle(wn)
    food.speed(0)
    food.shape("circle")
    food.color("red")
    food.penup()
    food.goto(0,100)
    food.shape("SnakeImage/Strawberry_2.gif")
    segments = []

    #Pen
    pen = RawTurtle(wn)
    pen.speed(0)
    pen.shape("square")
    pen.color("white")
    pen.penup()
    pen.hideturtle()
    pen.goto(0,260)
    pen.write("Score:0 High Score:0",align = "center",
              font = ("Courier",24,"normal"))

    def go_up():
        if head.direction != "down":
            head.direction = "up"

    def go_down():
        if head.direction != "up":
            head.direction = "down"

    def go_left():
        if head.direction != "right":
            head.direction = "left"

    def go_right():
        if head.direction != "left":
            head.direction = "right"

    def move():
        if head.direction == "up":
            y = head.ycor()
            head.sety(y+20)

        if head.direction == "down":
            y = head.ycor()
            head.sety(y-20)

        if head.direction == "left":
            x = head.xcor()
            head.setx(x-20)

        if head.direction == "right":
            x = head.xcor()
            head.setx(x+20)

    #key binding
    wn.listen()
    wn.onkey(go_up,"Up")
    wn.onkey(go_down,"Down")
    wn.onkey(go_left,"Left")
    wn.onkey(go_right,"Right")

    #main game loop
    while True:
        wn.update()

        #Check for a collision with the border
        if head.xcor()>345 or head.xcor()<-350 or head.ycor()>220 or head.ycor()<-220:
            winsound.PlaySound("SnakeImage/Boom.wav",winsound.SND_ASYNC)
            time.sleep(1)
            head.goto(0,0)
            head.direction = "stop"

            #hide the segments
            for segment in segments:
                segment.goto(1000,1000)

            #clear the segments list
            segments.clear()

            #Reset the score
            score = 0

            #reset the delay
            delay = 0.1

            pen.clear()
            pen.write("Score:{} High Score:{}".format(score,high_score),
                      align = "center",font = ("Agency FB",24,"normal"))

        #Check for a collision with the food
        if head.distance(food)<20:
            #move the food to a random spot
            winsound.PlaySound("SnakeImage/Crunch.wav",winsound.SND_ASYNC)
            x = random.randint(-350,345)
            y = random.randint(-220,220)
            food.goto(x,y)

            #Add a segment
            new_segment = RawTurtle(wn)
            new_segment.speed(0)
            new_segment.shape("circle")
            new_segment.color("#034504")
            new_segment.penup()
            segments.append(new_segment)

            #Shorten the delay
            delay-=0.001

            #increase the score
            score+=10

            if score>high_score:
                high_score = score

            pen.clear()
            pen.write("Score:{} High Score:{}".format(score,high_score),
                      align = "center",font = ("Agency FB",24,"normal"))

        #move the end segment first in reverse order
        for index in range(len(segments)-1,0,-1):
            x = segments[index-1].xcor()
            y = segments[index-1].ycor()
            segments[index].goto(x,y)

        #move segment 0 to where the head is
        if len(segments)>0:
            x = head.xcor()
            y = head.ycor()
            segments[0].goto(x,y)

        move()

        #check for head collision with the body segments
        for segment in segments:
            if segment.distance(head)<20:
                winsound.PlaySound("SnakeImage/Boom.wav",winsound.SND_ASYNC)
                time.sleep(1)
                head.goto(0,0)
                head.direction = "stop"

                #hide the segments
                for segment in segments:
                    segment.goto(1000,1000)

                #Clear the segments list
                segments.clear()

                #reset the score
                score = 0

                #reset the delay
                delay = 0.1
                        
                pen.clear()
                pen.write("Score:{} High Score:{}".format(score,high_score),
                          align = "center",font = ("Agency FB",24,"normal"))
        time.sleep(delay)
            
start_game = tk.Button(win,text = "Start",bg = "#070436",fg = "cyan",
                       activeforeground = "yellow",
                       font = ("Agency FB",18),
                       relief = "groove",width = 8,height = 1,command = start,bd = 4)
start_game.place(x = 380,y = 610)
win.mainloop()
