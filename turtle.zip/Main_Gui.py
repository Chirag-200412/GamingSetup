#------------------GUI Creation of tkinter--------------------------
import tkinter as tk
from PIL import Image,ImageTk
from Game_Area import *

screen = tk.Tk()
screen.title("----My Games----")
screen.geometry("1000x600")
screen["bg"] = "#070436"

#-----------Fit Image in background------------
path = "C:\\Users\\Lenovo\\OneDrive\\Documents\\Chirag\\turtle\\images\\giphy.gif"
image1 = tk.PhotoImage(file = path)
w = 1600
h = 800
screen.geometry("%dx%d+0+0"%(w,h))
lx = tk.Label(screen,image = image1)
lx.pack(side = "top",fill = "both",expand = "yes")

#----------------Games bar-----------------
l1 = tk.Label(screen,text = "Old Themed Gaming Setup",font = ("Agency FB",28),
              bd = 4,bg = "#060245",fg = "cyan")
l1.place(x = 640,y = 5)

button1 = tk.Button(screen,text = "Cannon",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = canon,bd = 4)
button1.place(x = 100,y = 80)

button2 = tk.Button(screen,text = "Bird",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Bird,bd = 4)
button2.place(x = 420,y = 80)

button3 = tk.Button(screen,text = "FootBall",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = FootBall,bd = 4)
button3.place(x = 740,y = 80)

button4 = tk.Button(screen,text = "IronMan",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Iron,bd = 4)
button4.place(x = 100,y = 230)

button5 = tk.Button(screen,text = "Snake",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Snake,bd = 4)
button5.place(x = 420,y = 230)

button6 = tk.Button(screen,text = "Alien",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Alien,bd = 4)
button6.place(x = 740,y = 230)

button7 = tk.Button(screen,text = "Race",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Race,bd = 4)
button7.place(x = 100,y = 380)

button8 = tk.Button(screen,text = "TicTacToe",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = TicTacToe,bd = 4)
button8.place(x = 420,y = 380)

button9 = tk.Button(screen,text = "RPS",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = RPS,bd = 4)
button9.place(x = 740,y = 380)

button10 = tk.Button(screen,text = "Ball",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Ball,bd = 4)
button10.place(x = 100,y = 530)

button11 = tk.Button(screen,text = "Ludo",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Ludo,bd = 4)
button11.place(x = 420,y = 530)

button12 = tk.Button(screen,text = "Battle",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Battle,bd = 4)
button12.place(x = 740,y = 530)

button13 = tk.Button(screen,text = "Archery",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Archery,bd = 4)
button13.place(x = 100,y = 680)

button14 = tk.Button(screen,text = "SNL",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = SnakesNLadders,bd = 4)
button14.place(x = 420,y = 680)

button15 = tk.Button(screen,text = "Car",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = CarRace,bd = 4)
button15.place(x = 740,y = 680)

button16 = tk.Button(screen,text = "Quiz",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Quiz,bd = 4)
button16.place(x = 1060,y = 80)

button17 = tk.Button(screen,text = "Checkers",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Checkers,bd = 4)
button17.place(x = 1060,y = 230)

button18 = tk.Button(screen,text = "Fighting",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Fighting,bd = 4)
button18.place(x = 1060,y = 380)

button19 = tk.Button(screen,text = "Mario",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Mario,bd = 4)
button19.place(x = 1060,y = 530)

button20 = tk.Button(screen,text = "Pacman",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Pacman,bd = 4)
button20.place(x = 1060,y = 680)

button21 = tk.Button(screen,text = "ArcDash",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = ArcDash,bd = 4)
button21.place(x = 1380,y = 80)

button22 = tk.Button(screen,text = "Puzzle",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Puzzle,bd = 4)
button22.place(x = 1380,y = 230)

button23 = tk.Button(screen,text = "Pool",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Pool,bd = 4)
button23.place(x = 1380,y = 380)

button24 = tk.Button(screen,text = "Carrom",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Carrom,bd = 4)
button24.place(x = 1380,y = 530)

button25 = tk.Button(screen,text = "Present",bg = "#070436",fg = "cyan",
                    activeforeground = "black",font = ("Agency FB",18),
                    relief = "groove",width = 8,height = 1,command = Present,bd = 4)
button25.place(x = 1380,y = 680)

screen.mainloop()
