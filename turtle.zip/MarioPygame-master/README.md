# MarioPygame

A python remake of the classic Super Mario Bros.

* [YouTube link](https://www.youtube.com/watch?v=WCkBDyX0qNI)

## About
**Note: The code is a bit messy. Live with it.
At the moment I was writing it I was a complete beginner so I was using 
[this](https://github.com/jakowskidev/uMario_Jakowski) project as a reference.**

The game based on pygame with loading .tmx level using pytmx.

Only level 1-1 was finished. 

That's how main menu looks:

![Main Menu](https://github.com/Winter091/MarioPygame/blob/master/Mario.png)


And gameplay:

![Gameplay](https://github.com/Winter091/MarioPygame/blob/master/Mario_gameplay.png)

## Starting
Install these python libraries:
```
pip install pygame
pip install pytmx
```

 Then execute 'Next/main.py'. 

