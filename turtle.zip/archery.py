import pygame
import sys
import random

pygame.init()

width,height = 800,600
screen = pygame.display.set_mode((width,height))
pygame.display.set_caption("Aim Your Target")

background_image = pygame.image.load("archeryimage/background.jpg")
archer_image = pygame.image.load("archeryimage/archer.png")
arrow_image = pygame.image.load("archeryimage/arrow.png")
enemy_image = pygame.image.load("archeryimage/enemy.png")

archer_rect = archer_image.get_rect()
archer_rect.center = (width // 2, height - 50)

arrow_rect = arrow_image.get_rect()

arrow_speed = 30
arrow_state = "fire"

enemies = []
enemy_speed = 5
enemy_frequency = 25
enemy_counter = 0

font = pygame.font.Font(None,36)

score = 0

while not any(enemy.y > archer_rect.centery for enemy in enemies):
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and arrow_state == "ready":
                arrow_rect.center = archer_rect.center
                arrow_state = "fire"

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and archer_rect.left > 0:
        archer_rect.x -= 10
    if keys[pygame.K_RIGHT] and archer_rect.right < width:
        archer_rect.x += 10

    if arrow_state == "fire":
        arrow_rect.y -= arrow_speed
        if arrow_rect.bottom < 0:
            arrow_state = "ready"

    if enemy_counter == enemy_frequency:
        enemy_rect = enemy_image.get_rect()
        enemy_rect.x = random.randint(0,width - enemy_rect.width)
        enemy_rect.y = -enemy_rect.height
        enemies.append(enemy_rect)
        enemy_counter = 0
    else:
        enemy_counter += 1

    for enemy in enemies:
        enemy.y += enemy_speed

    for enemy in enemies:
        if arrow_rect.colliderect(enemy):
            enemies.remove(enemy)
            arrow_state = "ready"
            score += 1

    screen.blit(background_image, (0, 0))

    screen.blit(archer_image, archer_rect)

    for enemy in enemies:
        screen.blit(enemy_image, enemy)

    if arrow_state == "fire":
        screen.blit(arrow_image,arrow_rect)

    score_text = font.render("Score: {}".format(score), True, (255, 255, 255))
    screen.blit(score_text, (10, 10))

    pygame.display.flip()
    if any(enemy.y > archer_rect.centery for enemy in enemies):
        break

    pygame.time.Clock().tick(20)

end_text = font.render("Game Over - Final Score: {}".format(score), True,(255, 255, 255))
screen.blit(end_text, (width // 2 - 150, height // 2 - 20))
pygame.display.flip()

pygame.time.delay(5000)
                
pygame.quit()
sys.exit()
