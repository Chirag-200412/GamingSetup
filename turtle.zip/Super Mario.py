from os import environ

import pygame as pg
from pygame.locals import *
from pytmx.util_pygame import load_pygame

class BGObject(object):
    def __init__(self, x, y, image):
        self.rect = pg.Rect(x, y, 32, 32)
        self.image = image
        self.type = 'BGObject'

    def render(self, core):
        core.screen.blit(self.image, core.get_map().get_camera().apply(self))
        
class Camera(object):
    def __init__(self, width, height):
        self.rect = pg.Rect(0, 0, width, height)
        self.complex_camera(self.rect)

    def complex_camera(self, target_rect):
        x, y = target_rect.x, target_rect.y
        width, height = self.rect.width, self.rect.height
        x, y = (-x + WINDOW_W / 2 - target_rect.width / 2), (-y + WINDOW_H / 2 - target_rect.height)

        x = min(0, x)
        x = max(-(self.rect.width - WINDOW_W), x)
        y = WINDOW_H - self.rect.h

        return pg.Rect(x, y, width, height)

    def apply(self, target):
        return target.rect.x + self.rect.x, target.rect.y

    def update(self, target):
        self.rect = self.complex_camera(target)

    def reset(self):
        self.rect = pg.Rect(0, 0, self.rect.w, self.rect.h)

class CoinDebris(object):
    def __init__(self, x_pos, y_pos):
        self.rect = pg.Rect(x_pos, y_pos, 16, 28)

        self.y_vel = -2
        self.y_offset = 0
        self.moving_up = True

        self.current_image = 0
        self.image_tick = 0
        self.images = [
            pg.image.load('images/coin_an0.png').convert_alpha(),
            pg.image.load('images/coin_an1.png').convert_alpha(),
            pg.image.load('images/coin_an2.png').convert_alpha(),
            pg.image.load('images/coin_an3.png').convert_alpha()
        ]

    def update(self, core):
        self.image_tick += 1

        if self.image_tick % 15 == 0:
            self.current_image += 1

        if self.current_image == 4:
            self.current_image = 0
            self.image_tick = 0

        if self.moving_up:
            self.y_offset += self.y_vel
            self.rect.y += self.y_vel
            if self.y_offset < -50:
                self.moving_up = False
                self.y_vel = -self.y_vel
        else:
            self.y_offset += self.y_vel
            self.rect.y += self.y_vel
            if self.y_offset == 0:
                core.get_map().debris.remove(self)

    def render(self, core):
        core.screen.blit(self.images[self.current_image], core.get_map().get_camera().apply(self))

WINDOW_W = 800
WINDOW_H = 448
FPS = 100

# Player physics
GRAVITY = 0.09
SPEED_INCREASE_RATE = 0.038
SPEED_DECREASE_RATE = 0.038
JUMP_POWER = 4.3
FALL_MULTIPLIER = 2.0
LOW_JUMP_MULTIPLIER = 3.0
MAX_MOVE_SPEED = 2.0
MAX_FASTMOVE_SPEED = 3.0
MAX_FALL_SPEED = 5.5

class Core(object):
    def __init__(self):
        environ['#'] = '1'
        pg.mixer.pre_init(44100, -16, 2, 1024)
        pg.init()
        pg.display.set_caption('Mario by techprogrammer007')
        pg.display.set_caption('@code_with_python_')
        pg.display.set_mode((WINDOW_W, WINDOW_H))

        self.screen = pg.display.set_mode((WINDOW_W, WINDOW_H))
        self.clock = pg.time.Clock()

        self.oWorld = Map('1-1')
        self.oSound = Sound()
        self.oMM = MenuManager(self)

        self.run = True
        self.keyR = False
        self.keyL = False
        self.keyU = False
        self.keyD = False
        self.keyShift = False

    def main_loop(self):
        while self.run:
            self.input()
            self.update()
            self.render()
            self.clock.tick(FPS)

    def input(self):
        if self.get_mm().currentGameState == 'Game':
            self.input_player()
        else:
            self.input_menu()

    def input_player(self):
        for e in pg.event.get():

            if e.type == pg.QUIT:
                self.run = False

            elif e.type == KEYDOWN:
                if e.key == K_RIGHT:
                    self.keyR = True
                elif e.key == K_LEFT:
                    self.keyL = True
                elif e.key == K_DOWN:
                    self.keyD = True
                elif e.key == K_UP:
                    self.keyU = True
                elif e.key == K_LSHIFT:
                    self.keyShift = True

            elif e.type == KEYUP:
                if e.key == K_RIGHT:
                    self.keyR = False
                elif e.key == K_LEFT:
                    self.keyL = False
                elif e.key == K_DOWN:
                    self.keyD = False
                elif e.key == K_UP:
                    self.keyU = False
                elif e.key == K_LSHIFT:
                    self.keyShift = False

    def input_menu(self):
        for e in pg.event.get():
            if e.type == pg.QUIT:
                self.run = False

            elif e.type == KEYDOWN:
                if e.key == K_RETURN:
                    self.get_mm().start_loading()

    def update(self):
        self.get_mm().update(self)

    def render(self):
        self.get_mm().render(self)

    def get_map(self):
        return self.oWorld

    def get_mm(self):
        return self.oMM

    def get_sound(self):
        return self.oSound

class DebugTable(object):
    def __init__(self):
        self.font = pg.font.SysFont('Consolas', 12)
        self.darkArea = pg.Surface((200, 100)).convert_alpha()
        self.darkArea.fill((0, 0, 0, 200))
        self.text = []
        self.rect = 0
        self.offsetX = 12
        self.x = 5
        self.mode = 2

    def update_text(self, core):
        if self.mode == 2:
            self.text = [
                'FPS: ' + str(int(core.clock.get_fps())),
                'Rect: ' + str(core.get_map().get_player().rect.x) + ' ' + str(core.get_map().get_player().rect.y) + ' h: ' + str(core.get_map().get_player().rect.h),
                'g: ' + str(core.get_map().get_player().on_ground) + ' LVL: ' + str(core.get_map().get_player().powerLVL) + ' inv: ' + str(core.get_map().get_player().unkillable),
                'Spr: ' + str(core.get_map().get_player().spriteTick) + ' J lock: ' + str(core.get_map().get_player().already_jumped),
                'Up  : ' + str(core.get_map().get_player().inLevelUpAnimation) + '  time: ' + str(core.get_map().get_player().inLevelUpAnimationTime),
                'Down: ' + str(core.get_map().get_player().inLevelDownAnimation) + '  time: ' + str(core.get_map().get_player().inLevelDownAnimationTime),
                'Mobs: ' + str(len(core.get_map().get_mobs())) + ' FB: ' + str(len(core.get_map().projectiles)) + ' Debris: ' + str(len(core.get_map().debris))
            ]

    def render(self, core):
        self.x = 105
        if self.mode == 2:
            core.screen.blit(self.darkArea, (0, 100))
            for string in self.text:
                self.rect = self.font.render(string, True, (255, 255, 255))
                core.screen.blit(self.rect, (5, self.x))
                self.x += self.offsetX

class Entity(object):
    def __init__(self):

        self.state = 0
        self.x_vel = 0
        self.y_vel = 0

        self.move_direction = True
        self.on_ground = False
        self.collision = True

        self.image = None
        self.rect = None

    def update_x_pos(self, blocks):
        self.rect.x += self.x_vel

        for block in blocks:
            if block != 0 and block.type != 'BGObject':
                if pg.Rect.colliderect(self.rect, block.rect):
                    if self.x_vel > 0:
                        self.rect.right = block.rect.left
                        self.x_vel = - self.x_vel
                    elif self.x_vel < 0:
                        self.rect.left = block.rect.right
                        self.x_vel = - self.x_vel

    def update_y_pos(self, blocks):
        self.rect.y += self.y_vel * FALL_MULTIPLIER

        self.on_ground = False
        for block in blocks:
            if block != 0 and block.type != 'BGObject':
                if pg.Rect.colliderect(self.rect, block.rect):
                    if self.y_vel > 0:
                        self.on_ground = True
                        self.rect.bottom = block.rect.top
                        self.y_vel = 0

    def check_map_borders(self, core):
        if self.rect.y >= 448:
            self.die(core, True, False)
        if self.rect.x <= 1 and self.x_vel < 0:
            self.x_vel = - self.x_vel

    def die(self, core, instantly, crushed):
        pass

    def render(self, core):
        pass

class Fireball(object):
    def __init__(self, x_pos, y_pos, move_direction: bool):
        super().__init__()

        self.rect = pg.Rect(x_pos, y_pos, 16, 16)
        self.state = 0
        self.direction = move_direction
        self.x_vel = 5 if move_direction else -5
        self.y_vel = 0

        self.current_image = 0
        self.image_tick = 0
        self.images = [pg.image.load('images/fireball.png').convert_alpha()]
        self.images.append(pg.transform.flip(self.images[0], 0, 90))
        self.images.append(pg.transform.flip(self.images[0], 90, 90))
        self.images.append(pg.transform.flip(self.images[0], 90, 0))
        self.images.append(pg.image.load('images/firework0.png').convert_alpha())
        self.images.append(pg.image.load('images/firework1.png').convert_alpha())
        self.images.append(pg.image.load('images/firework2.png').convert_alpha())

    def update_image(self, core):
        self.image_tick += 1

        if self.state == 0:
            if self.image_tick % 15 == 0:
                self.current_image += 1
                if self.current_image > 3:
                    self.current_image = 0
                    self.image_tick = 0

        elif self.state == -1:
            if self.image_tick % 10 == 0:
                self.current_image += 1
            if self.current_image == 7:
                core.get_map().remove_whizbang(self)

    def start_boom(self):
        self.x_vel = 0
        self.y_vel = 0
        self.current_image = 4
        self.image_tick = 0
        self.state = -1

    def update_x_pos(self, blocks):
        self.rect.x += self.x_vel
      
        for block in blocks:
            if block != 0 and block.type != 'BGObject':
                if pg.Rect.colliderect(self.rect, block.rect):

                    # Fireball blows up only when collides on x-axis
                    self.start_boom()

    def update_y_pos(self, blocks):
        self.rect.y += self.y_vel
        for block in blocks:
            if block != 0 and block.type != 'BGObject':
                if pg.Rect.colliderect(self.rect, block.rect):
                    self.rect.bottom = block.rect.top
                    self.y_vel = -3

    def check_map_borders(self, core):
        if self.rect.x <= 0:
            core.get_map().remove_whizbang(self)
        elif self.rect.x >= 6768:
            core.get_map().remove_whizbang(self)
        elif self.rect.y > 448:
            core.get_map().remove_whizbang(self)

    def move(self, core):
        self.y_vel += GRAVITY

        blocks = core.get_map().get_blocks_for_collision(self.rect.x // 32, self.rect.y // 32)
        self.update_y_pos(blocks)
        self.update_x_pos(blocks)

        self.check_map_borders(core)

    def check_collision_with_mobs(self, core):
        for mob in core.get_map().get_mobs():
            if self.rect.colliderect(mob.rect):
                if mob.collision:
                    mob.die(core, instantly=False, crushed=False)
                    self.start_boom()

    def update(self, core):
        if self.state == 0:
            self.update_image(core)
            self.move(core)
            self.check_collision_with_mobs(core)
        elif self.state == -1:
            self.update_image(core)

    def render(self, core):
        core.screen.blit(self.images[self.current_image], core.get_map().get_camera().apply(self))

class Flag(object):
    def __init__(self, x_pos, y_pos):
        self.rect = None

        self.flag_offset = 0
        self.flag_omitted = False

        # Flag object consists of 2 parts:

        self.pillar_image = pg.image.load('images/flag_pillar.png').convert_alpha()
        self.pillar_rect = pg.Rect(x_pos + 8, y_pos, 16, 304)

        self.flag_image = pg.image.load('images/flag.png').convert_alpha()
        self.flag_rect = pg.Rect(x_pos - 18, y_pos + 16, 32, 32)

    def move_flag_down(self):
        self.flag_offset += 3
        self.flag_rect.y += 3

        if self.flag_offset >= 255:
            self.flag_omitted = True

    def render(self, core):
        self.rect = self.pillar_rect
        core.screen.blit(self.pillar_image, core.get_map().get_camera().apply(self))

        self.rect = self.flag_rect
        core.screen.blit(self.flag_image, core.get_map().get_camera().apply(self))

class Flower(Entity):
    def __init__(self, x_pos, y_pos):
        super().__init__()

        self.rect = pg.Rect(x_pos, y_pos, 32, 32)
        self.spawned = False
        self.spawn_y_offset = 0

        self.current_image = 0
        self.image_tick = 0
        self.images = (
            pg.image.load('images/flower0.png').convert_alpha(),
            pg.image.load('images/flower1.png').convert_alpha(),
            pg.image.load('images/flower2.png').convert_alpha(),
            pg.image.load('images/flower3.png').convert_alpha()
        )

    def check_collision_with_player(self, core):
        if self.rect.colliderect(core.get_map().get_player().rect):
            core.get_map().get_player().set_powerlvl(3, core)
            core.get_map().get_mobs().remove(self)

    def update_image(self):
        self.image_tick += 1

        if self.image_tick == 60:
            self.image_tick = 0
            self.current_image = 0

        elif self.image_tick % 15 == 0:
            self.current_image += 1

    def spawn_animation(self):
        self.spawn_y_offset -= 1
        self.rect.y -= 1

        if self.spawn_y_offset == -32:
            self.spawned = True

    def update(self, core):
        if self.spawned:
            self.update_image()
        else:
            self.spawn_animation()

    def render(self, core):
        core.screen.blit(self.images[self.current_image], core.get_map().get_camera().apply(self))

class GameUI(object):
    def __init__(self):
        self.font = pg.font.Font('fonts/emulogic.ttf', 20)
        self.text = 'SCORE COINS WORLD TIME LIVES'

    def render(self, core):
        x = 10
        for word in self.text.split(' '):
            rect = self.font.render(word, False, (255, 255, 255))
            core.screen.blit(rect, (x, 0))
            x += 168

        text = self.font.render(str(core.get_map().get_player().score), False, (255, 255, 255))
        rect = text.get_rect(center=(60, 35))
        core.screen.blit(text, rect)

        text = self.font.render(str(core.get_map().get_player().coins), False, (255, 255, 255))
        rect = text.get_rect(center=(230, 35))
        core.screen.blit(text, rect)

        text = self.font.render(core.get_map().get_name(), False, (255, 255, 255))
        rect = text.get_rect(center=(395, 35))
        core.screen.blit(text, rect)

        text = self.font.render(str(core.get_map().time), False, (255, 255, 255))
        rect = text.get_rect(center=(557, 35))
        core.screen.blit(text, rect)

        text = self.font.render(str(core.get_map().get_player().numOfLives), False, (255, 255, 255))
        rect = text.get_rect(center=(730, 35))
        core.screen.blit(text, rect)

class Goombas(Entity):
    def __init__(self, x_pos, y_pos, move_direction):
        super().__init__()
        self.rect = pg.Rect(x_pos, y_pos, 32, 32)

        if move_direction:
            self.x_vel = 1
        else:
            self.x_vel = -1

        self.crushed = False

        self.current_image = 0
        self.image_tick = 0
        self.images = [
            pg.image.load('images/goombas_0.png').convert_alpha(),
            pg.image.load('images/goombas_1.png').convert_alpha(),
            pg.image.load('images/goombas_dead.png').convert_alpha()
        ]
        self.images.append(pg.transform.flip(self.images[0], 0, 180))

    def die(self, core, instantly, crushed):
        if not instantly:
            core.get_map().get_player().add_score(core.get_map().score_for_killing_mob)
            core.get_map().spawn_score_text(self.rect.x + 16, self.rect.y)

            if crushed:
                self.crushed = True
                self.image_tick = 0
                self.current_image = 2
                self.state = -1
                core.get_sound().play('kill_mob', 0, 0.5)
                self.collision = False

            else:
                self.y_vel = -4
                self.current_image = 3
                core.get_sound().play('shot', 0, 0.5)
                self.state = -1
                self.collision = False

        else:
            core.get_map().get_mobs().remove(self)

    def check_collision_with_player(self, core):
        if self.collision:
            if self.rect.colliderect(core.get_map().get_player().rect):
                if self.state != -1:
                    if core.get_map().get_player().y_vel > 0:
                        self.die(core, instantly=False, crushed=True)
                        core.get_map().get_player().reset_jump()
                        core.get_map().get_player().jump_on_mob()
                    else:
                        if not core.get_map().get_player().unkillable:
                            core.get_map().get_player().set_powerlvl(0, core)

    def update_image(self):
        self.image_tick += 1
        if self.image_tick == 14:
            self.current_image = 1
        elif self.image_tick == 28:
            self.current_image = 0
            self.image_tick = 0

    def update(self, core):
        if self.state == 0:
            self.update_image()

            if not self.on_ground:
                self.y_vel += GRAVITY

            blocks = core.get_map().get_blocks_for_collision(int(self.rect.x // 32), int(self.rect.y // 32))
            self.update_x_pos(blocks)
            self.update_y_pos(blocks)

            self.check_map_borders(core)

        elif self.state == -1:
            if self.crushed:
                self.image_tick += 1
                if self.image_tick == 50:
                    core.get_map().get_mobs().remove(self)
            else:
                self.y_vel += GRAVITY
                self.rect.y += self.y_vel
                self.check_map_borders(core)

    def render(self, core):
        core.screen.blit(self.images[self.current_image], core.get_map().get_camera().apply(self))

class Koopa(Entity):
    def __init__(self, x_pos, y_pos, move_direction):
        super().__init__()
        self.rect = pg.Rect(x_pos, y_pos, 32, 46)

        self.move_direction = move_direction

        if move_direction:
            self.x_vel = 1
        else:
            self.x_vel = -1

        self.current_image = 0
        self.image_tick = 0
        self.images = [
            pg.image.load('images/koopa_0.png').convert_alpha(),
            pg.image.load('images/koopa_1.png').convert_alpha(),
            pg.image.load('images/koopa_dead.png').convert_alpha()
        ]
        self.images.append(pg.transform.flip(self.images[0], 180, 0))
        self.images.append(pg.transform.flip(self.images[1], 180, 0))
        self.images.append(pg.transform.flip(self.images[2], 0, 180))

    """
    States: 
    0 - Just walking around
    1 - Hidden 
    2 - Hidden and fast moving
    -1 - Dead
    """

    def check_collision_with_player(self, core):
        if self.collision:
            if self.rect.colliderect(core.get_map().get_player().rect):
                if self.state != -1:
                    if core.get_map().get_player().y_vel > 0:
                        self.change_state(core)
                        core.get_sound().play('kill_mob', 0, 0.5)
                        core.get_map().get_player().reset_jump()
                        core.get_map().get_player().jump_on_mob()
                    else:
                        if not core.get_map().get_player().unkillable:
                            core.get_map().get_player().set_powerlvl(0, core)

    def check_collision_with_mobs(self, core):
        for mob in core.get_map().get_mobs():
            if mob is not self:
                if self.rect.colliderect(mob.rect):
                    if mob.collision:
                        mob.die(core, instantly=False, crushed=False)

    def die(self, core, instantly, crushed):
        if not instantly:
            core.get_map().get_player().add_score(core.get_map().score_for_killing_mob)
            core.get_map().spawn_score_text(self.rect.x + 16, self.rect.y)
            self.state = -1
            self.y_vel = -4
            self.current_image = 5
        else:
            core.get_map().get_mobs().remove(self)

    def change_state(self, core):
        self.state += 1
        self.current_image = 2

        # 0 to 1 state
        if self.rect.h == 46:
            self.x_vel = 0
            self.rect.h = 32
            self.rect.y += 14
            core.get_map().get_player().add_score(100)
            core.get_map().spawn_score_text(self.rect.x + 16, self.rect.y, score=100)

        # 1 to 2
        elif self.state == 2:
            core.get_map().get_player().add_score(100)
            core.get_map().spawn_score_text(self.rect.x + 16, self.rect.y, score=100)

            if core.get_map().get_player().rect.x - self.rect.x <= 0:
                self.x_vel = 6
            else:
                self.x_vel = -6

        # 2 to 3
        elif self.state == 3:
            self.die(core, instantly=False, crushed=False)

    def update_image(self):
        self.image_tick += 1

        if self.x_vel > 0:
            self.move_direction = True
        else:
            self.move_direction = False

        if self.image_tick == 35:
            if self.move_direction:
                self.current_image = 4
            else:
                self.current_image = 1
        elif self.image_tick == 70:
            if self.move_direction:
                self.current_image = 3
            else:
                self.current_image = 0
            self.image_tick = 0

    def update(self, core):
        if self.state == 0:
            self.update_image()

            if not self.on_ground:
                self.y_vel += GRAVITY

            blocks = core.get_map().get_blocks_for_collision(self.rect.x // 32, (self.rect.y - 14) // 32)
            self.update_x_pos(blocks)
            self.update_y_pos(blocks)

            self.check_map_borders(core)

        elif self.state == 1:
            blocks = core.get_map().get_blocks_for_collision(self.rect.x // 32, self.rect.y // 32)
            self.update_x_pos(blocks)
            self.update_y_pos(blocks)

            self.check_map_borders(core)

        elif self.state == 2:
            if not self.on_ground:
                self.y_vel += GRAVITY

            blocks = core.get_map().get_blocks_for_collision(self.rect.x // 32, self.rect.y // 32)
            self.update_x_pos(blocks)
            self.update_y_pos(blocks)

            self.check_map_borders(core)
            self.check_collision_with_mobs(core)

        elif self.state == -1:
            self.rect.y += self.y_vel
            self.y_vel += GRAVITY

            self.check_map_borders(core)

    def render(self, core):
        core.screen.blit(self.images[self.current_image], core.get_map().get_camera().apply(self))

class LoadingMenu(object):
    def __init__(self, core):
        self.iTime = pg.time.get_ticks()
        self.loadingType = True
        self.bg = pg.Surface((WINDOW_W, WINDOW_H))
        self.text = Text('WORLD ' + core.oWorld.get_name(), 32, (WINDOW_W / 2, WINDOW_H / 2))

    def update(self, core):
        if pg.time.get_ticks() >= self.iTime + (5250 if not self.loadingType else 2500):
            if self.loadingType:
                core.oMM.currentGameState = 'Game'
                core.get_sound().play('overworld', 999999, 0.5)
                core.get_map().in_event = False
            else:
                core.oMM.currentGameState = 'MainMenu'
                self.set_text_and_type('WORLD ' + core.oWorld.get_name(), True)
                core.get_map().reset(True)

    def set_text_and_type(self, text, type):
        self.text = Text(text, 32, (WINDOW_W / 2, WINDOW_H / 2))
        self.loadingType = type

    def render(self, core):
        core.screen.blit(self.bg, (0, 0))
        self.text.render(core)

    def update_time(self):
        self.iTime = pg.time.get_ticks()

class MainMenu(object):
    def __init__(self):
        self.mainImage = pg.image.load(r'images\super_mario_bros.png').convert_alpha()

        self.toStartText = Text('Press ENTER to start', 16, (WINDOW_W - WINDOW_W * 0.72, WINDOW_H - WINDOW_H * 0.3))

    def render(self, core):
        core.screen.blit(self.mainImage, (50, 50))
        self.toStartText.render(core)

class Map(object):
    """

    This class contains every map object: tiles, mobs and player. Also,
    there are camera, event and UI.

    """

    def __init__(self, world_num):
        self.obj = []
        self.obj_bg = []
        self.tubes = []
        self.debris = []
        self.mobs = []
        self.projectiles = []
        self.text_objects = []
        self.map = 0
        self.flag = None

        self.mapSize = (0, 0)
        self.sky = 0

        self.textures = {}
        self.worldNum = world_num
        self.loadWorld_11()

        self.is_mob_spawned = [False, False]
        self.score_for_killing_mob = 100
        self.score_time = 0

        self.in_event = False
        self.tick = 0
        self.time = 400

        self.oPlayer = Player(x_pos=128, y_pos=351)
        self.oCamera = Camera(self.mapSize[0] * 32, 14)
        self.oEvent = Event()
        self.oGameUI = GameUI()

    def loadWorld_11(self):
        tmx_data = load_pygame("worlds/1-1/W11.tmx")
        self.mapSize = (tmx_data.width, tmx_data.height)

        self.sky = pg.Surface((WINDOW_W, WINDOW_H))
        self.sky.fill((pg.Color('#5c94fc')))

        # 2D List
        self.map = [[0] * tmx_data.height for i in range(tmx_data.width)]

        layer_num = 0
        for layer in tmx_data.visible_layers:
            for y in range(tmx_data.height):
                for x in range(tmx_data.width):

                    # Getting pygame surface
                    image = tmx_data.get_tile_image(x, y, layer_num)

                    # It's none if there are no tile in that place
                    if image is not None:
                        tileID = tmx_data.get_tile_gid(x, y, layer_num)

                        if layer.name == 'Foreground':

                            # 22 ID is a question block, so in taht case we shoud load all it's images
                            if tileID == 22:
                                image = (
                                    image,                                      # 1
                                    tmx_data.get_tile_image(0, 15, layer_num),   # 2
                                    tmx_data.get_tile_image(1, 15, layer_num),   # 3
                                    tmx_data.get_tile_image(2, 15, layer_num)    # activated
                                )

                            # Map class has 1)"map" list, which is used in collision system because we can
                            # easily get block by x and y coordinate 2)"obj", "obj_bg" and simular arrays -
                            # they are used in rendering because you don't need to cycle through every
                            # (x, y) pair. Here we are adding the same platform object in 2 different arrays.
                            self.map[x][y] = Platform(x * tmx_data.tileheight, y * tmx_data.tilewidth, image, tileID)
                            self.obj.append(self.map[x][y])

                        elif layer.name == 'Background':
                            self.map[x][y] = BGObject(x * tmx_data.tileheight, y * tmx_data.tilewidth, image)
                            self.obj_bg.append(self.map[x][y])
            layer_num += 1

        # Tubes
        self.spawn_tube(28, 10)
        self.spawn_tube(37, 9)
        self.spawn_tube(46, 8)
        self.spawn_tube(55, 8)
        self.spawn_tube(163, 10)
        self.spawn_tube(179, 10)

        # Mobs
        self.mobs.append(Goombas(736, 352, False))
        self.mobs.append(Goombas(1295, 352, True))
        self.mobs.append(Goombas(1632, 352, False))
        self.mobs.append(Goombas(1672, 352, False))
        self.mobs.append(Goombas(5570, 352, False))
        self.mobs.append(Goombas(5620, 352, False))

        self.map[21][8].bonus = 'mushroom'
        self.map[78][8].bonus = 'mushroom'
        self.map[109][4].bonus = 'mushroom'

        self.flag = Flag(6336, 48)

    def reset(self, reset_all):
        self.obj = []
        self.obj_bg = []
        self.tubes = []
        self.debris = []
        self.mobs = []
        self.is_mob_spawned = [False, False]

        self.in_event = False
        self.flag = None
        self.sky = None
        self.map = None

        self.tick = 0
        self.time = 400

        self.mapSize = (0, 0)
        self.textures = {}
        self.loadWorld_11()

        self.get_event().reset()
        self.get_player().reset(reset_all)
        self.get_camera().reset()

    def get_name(self):
        if self.worldNum == '1-1':
            return '1-1'

    def get_player(self):
        return self.oPlayer

    def get_camera(self):
        return self.oCamera

    def get_event(self):
        return self.oEvent

    def get_ui(self):
        return self.oGameUI

    def get_blocks_for_collision(self, x, y):
        """

        Returns tiles around the entity

        """
        return (
            self.map[x][y - 1],
            self.map[x][y + 1],
            self.map[x][y],
            self.map[x - 1][y],
            self.map[x + 1][y],
            self.map[x + 2][y],
            self.map[x + 1][y - 1],
            self.map[x + 1][y + 1],
            self.map[x][y + 2],
            self.map[x + 1][y + 2],
            self.map[x - 1][y + 1],
            self.map[x + 2][y + 1],
            self.map[x][y + 3],
            self.map[x + 1][y + 3]
        )

    def get_blocks_below(self, x, y):
        """

        Returns 2 blocks below entity to check its on_ground parameter

        """
        return (
            self.map[x][y + 1],
            self.map[x + 1][y + 1]
        )

    def get_mobs(self):
        return self.mobs

    def spawn_tube(self, x_coord, y_coord):
        self.tubes.append(Tube(x_coord, y_coord))

        # Adding tube's collision just by spawning tiles inside the tube.
        # They will not render because we are adding them to "collision" list.
        for y in range(y_coord, 12): # 12 because it's ground level.
            for x in range(x_coord, x_coord + 2):
                self.map[x][y] = Platform(x * 32, y * 32, image=None, type_id=0)

    def spawn_mushroom(self, x, y):
        self.get_mobs().append(Mushroom(x, y, True))

    def spawn_goombas(self, x, y, move_direction):
        self.get_mobs().append(Goombas(x, y, move_direction))

    def spawn_koopa(self, x, y, move_direction):
        self.get_mobs().append(Koopa(x, y, move_direction))

    def spawn_flower(self, x, y):
        self.mobs.append(Flower(x, y))

    def spawn_debris(self, x, y, type):
        if type == 0:
            self.debris.append(PlatformDebris(x, y))
        elif type == 1:
            self.debris.append(CoinDebris(x, y))

    def spawn_fireball(self, x, y, move_direction):
        self.projectiles.append(Fireball(x, y, move_direction))

    def spawn_score_text(self, x, y, score=None):
        """

        This text appears when you, for example, kill a mob. It shows how many points
        you got.

        """

        # Score is none only when you kill a mob. If you got a killstreak,
        # amount of points for killing a mob will increase: 100, 200, 400, 800...
        # So you don't know how many points you should add.
        if score is None:
            self.text_objects.append(Text(str(self.score_for_killing_mob), 16, (x, y)))

            # Next score will be bigger
            self.score_time = pg.time.get_ticks()
            if self.score_for_killing_mob < 1600:
                self.score_for_killing_mob *= 2

        # That case for all other situations.
        else:
            self.text_objects.append(Text(str(score), 16, (x, y)))

    def remove_object(self, object):
        self.obj.remove(object)
        self.map[object.rect.x // 32][object.rect.y // 32] = 0

    def remove_whizbang(self, whizbang):
        self.projectiles.remove(whizbang)

    def remove_text(self, text_object):
        self.text_objects.remove(text_object)

    def update_player(self, core):
        self.get_player().update(core)

    def update_entities(self, core):
        for mob in self.mobs:
            mob.update(core)
            if not self.in_event:
                self.entity_collisions(core)

    def update_time(self, core):
        """

        Updating a map time.

        """

        # Time updates only if map not in event
        if not self.in_event:
            self.tick += 1
            if self.tick % 40 == 0:
                self.time -= 1
                self.tick = 0
            if self.time == 100 and self.tick == 1:
                core.get_sound().start_fast_music(core)
            elif self.time == 0:
                self.player_death(core)

    def update_score_time(self):
        """

        When player kill mobs in a row, score for each mob
        will increase. When player stops kill mobs, points
        will reset to 100. This function updates these points.

        """
        if self.score_for_killing_mob != 100:

            # Delay is 750 ms
            if pg.time.get_ticks() > self.score_time + 750:
                self.score_for_killing_mob //= 2

    def entity_collisions(self, core):
        if not core.get_map().get_player().unkillable:
            for mob in self.mobs:
                mob.check_collision_with_player(core)

    def try_spawn_mobs(self, core):
        """

        These mobs will appear when player will reach the certain x-coordinate

        """
        if self.get_player().rect.x > 2080 and not self.is_mob_spawned[0]:
            self.spawn_goombas(2495, 224, False)
            self.spawn_goombas(2560, 96, False)
            self.is_mob_spawned[0] = True

        elif self.get_player().rect.x > 2460 and not self.is_mob_spawned[1]:
            self.spawn_goombas(3200, 352, False)
            self.spawn_goombas(3250, 352, False)
            self.spawn_koopa(3400, 352, False)
            self.spawn_goombas(3700, 352, False)
            self.spawn_goombas(3750, 352, False)
            self.spawn_goombas(4060, 352, False)
            self.spawn_goombas(4110, 352, False)
            self.spawn_goombas(4190, 352, False)
            self.spawn_goombas(4240, 352, False)
            self.is_mob_spawned[1] = True

    def player_death(self, core):
        self.in_event = True
        self.get_player().reset_jump()
        self.get_player().reset_move()
        self.get_player().numOfLives -= 1

        if self.get_player().numOfLives == 0:
            self.get_event().start_kill(core, game_over=True)
        else:
            self.get_event().start_kill(core, game_over=False)

    def player_win(self, core):
        self.in_event = True
        self.get_player().reset_jump()
        self.get_player().reset_move()
        self.get_event().start_win(core)

    def update(self, core):

        # All mobs
        self.update_entities(core)

        if not core.get_map().in_event:

            # When player eats a mushroom
            if self.get_player().inLevelUpAnimation:
                self.get_player().change_powerlvl_animation()

            # Unlike the level up animation, player can move there
            elif self.get_player().inLevelDownAnimation:
                self.get_player().change_powerlvl_animation()
                self.update_player(core)

            # Common case
            else:
                self.update_player(core)

        else:
            self.get_event().update(core)

        # Debris is 1) Particles which appears when player destroy a brick block
        # 2) Coins which appears when player activate a "question" platform
        for debris in self.debris:
            debris.update(core)

        # Player's fireballs
        for whizbang in self.projectiles:
            whizbang.update(core)

        # Text which represent how mapy points player get
        for text_object in self.text_objects:
            text_object.update(core)

        # Camera stops moving when player dies or touches a flag
        if not self.in_event:
            self.get_camera().update(core.get_map().get_player().rect)

        self.try_spawn_mobs(core)

        self.update_time(core)
        self.update_score_time()

    def render_map(self, core):
        """

        Rendering only tiles. It's used in main menu.

        """
        core.screen.blit(self.sky, (0, 0))

        for obj_group in (self.obj_bg, self.obj):
            for obj in obj_group:
                obj.render(core)

        for tube in self.tubes:
            tube.render(core)

    def render(self, core):
        """

        Renders every object.

        """
        core.screen.blit(self.sky, (0, 0))

        for obj in self.obj_bg:
            obj.render(core)

        for mob in self.mobs:
            mob.render(core)

        for obj in self.obj:
            obj.render(core)

        for tube in self.tubes:
            tube.render(core)

        for whizbang in self.projectiles:
            whizbang.render(core)

        for debris in self.debris:
            debris.render(core)

        self.flag.render(core)

        for text_object in self.text_objects:
            text_object.render_in_game(core)

        self.get_player().render(core)

        self.get_ui().render(core)

class MenuManager(object):
    def __init__(self, core):

        self.currentGameState = 'MainMenu'

        self.oMainMenu = MainMenu()
        self.oLoadingMenu = LoadingMenu(core)

    def update(self, core):
        if self.currentGameState == 'MainMenu':
            pass

        elif self.currentGameState == 'Loading':
            self.oLoadingMenu.update(core)

        elif self.currentGameState == 'Game':
            core.get_map().update(core)

    def render(self, core):
        if self.currentGameState == 'MainMenu':
            core.get_map().render_map(core)
            self.oMainMenu.render(core)

        elif self.currentGameState == 'Loading':
            self.oLoadingMenu.render(core)

        elif self.currentGameState == 'Game':
            core.get_map().render(core)
            core.get_map().get_ui().render(core)

        pg.display.update()

    def start_loading(self):
            # Start to load the level
            self.currentGameState = 'Loading'
            self.oLoadingMenu.update_time()

class Mushroom(Entity):
    def __init__(self, x_pos, y_pos, move_direction):
        super().__init__()

        self.rect = pg.Rect(x_pos, y_pos, 32, 32)

        if move_direction:
            self.x_vel = 1
        else:
            self.x_vel = -1

        self.spawned = False
        self.spawn_y_offset = 0
        self.image = pg.image.load('images/mushroom.png').convert_alpha()

    def check_collision_with_player(self, core):
        if self.rect.colliderect(core.get_map().get_player().rect):
            core.get_map().get_player().set_powerlvl(2, core)
            core.get_map().get_mobs().remove(self)

    def die(self, core, instantly, crushed):
        core.get_map().get_mobs().remove(self)

    def spawn_animation(self):
        self.spawn_y_offset -= 1
        self.rect.y -= 1

        if self.spawn_y_offset == - 32:
            self.spawned = True

    def update(self, core):
        if self.spawned:
            if not self.on_ground:
                self.y_vel += GRAVITY

            blocks = core.get_map().get_blocks_for_collision(self.rect.x // 32, self.rect.y // 32)
            self.update_x_pos(blocks)
            self.update_y_pos(blocks)

            self.check_map_borders(core)
        else:
            self.spawn_animation()

    def render(self, core):
        core.screen.blit(self.image, core.get_map().get_camera().apply(self))

class Platform(object):
    def __init__(self, x, y, image, type_id):
        self.image = image
        self.rect = pg.Rect(x, y, 32, 32)

        # 22 - question block
        # 23 - brick block
        self.typeID = type_id

        self.type = 'Platform'

        self.shaking = False
        self.shakingUp = True
        self.shakeOffset = 0

        if self.typeID == 22:
            self.currentImage = 0
            self.imageTick = 0
            self.isActivated = False
            self.bonus = 'coin'

    def update(self):
        if self.typeID == 22:
            self.imageTick += 1
            if self.imageTick == 50:
                self.currentImage = 1
            elif self.imageTick == 60:
                self.currentImage = 2
            elif self.imageTick == 70:
                self.currentImage = 1
            elif self.imageTick == 80:
                self.currentImage = 0
                self.imageTick = 0

    def shake(self):
        if self.shakingUp:
            self.shakeOffset -= 2
            self.rect.y -= 2
        else:
            self.shakeOffset += 2
            self.rect.y += 2
        if self.shakeOffset == -20:
            self.shakingUp = False
        if self.shakeOffset == 0:
            self.shaking = False
            self.shakingUp = True

    def spawn_bonus(self, core):
        self.isActivated = True
        self.shaking = True
        self.imageTick = 0
        self.currentImage = 3

        if self.bonus == 'mushroom':
            core.get_sound().play('mushroom_appear', 0, 0.5)
            if core.get_map().get_player().powerLVL == 0:
                core.get_map().spawn_mushroom(self.rect.x, self.rect.y)
            else:
                core.get_map().spawn_flower(self.rect.x, self.rect.y)

        elif self.bonus == 'coin':
            core.get_sound().play('coin', 0, 0.5)
            core.get_map().spawn_debris(self.rect.x + 8, self.rect.y - 32, 1)
            core.get_map().get_player().add_coins(1)
            core.get_map().get_player().add_score(200)

    def destroy(self, core):
        core.get_map().spawn_debris(self.rect.x, self.rect.y, 0)
        core.get_map().remove_object(self)

    def render(self, core):

        # Question block
        if self.typeID == 22:
            if not self.isActivated:
                self.update()
            elif self.shaking:
                self.shake()
            core.screen.blit(self.image[self.currentImage], core.get_map().get_camera().apply(self))

        # Brick block
        elif self.typeID == 23 and self.shaking:
            self.shake()
            core.screen.blit(self.image, core.get_map().get_camera().apply(self))

        else:
            core.screen.blit(self.image, core.get_map().get_camera().apply(self))

class PlatformDebris(object):
    def __init__(self, x_pos, y_pos):
        self.image = pg.image.load('images/block_debris0.png').convert_alpha()

        # 4 different parts
        self.rectangles = [
            pg.Rect(x_pos - 20, y_pos + 16, 16, 16),
            pg.Rect(x_pos - 20, y_pos - 16, 16, 16),
            pg.Rect(x_pos + 20, y_pos + 16, 16, 16),
            pg.Rect(x_pos + 20, y_pos - 16, 16, 16)
        ]
        self.y_vel = -4
        self.rect = None

    def update(self, core):
        self.y_vel += GRAVITY * FALL_MULTIPLIER

        for i in range(len(self.rectangles)):
            self.rectangles[i].y += self.y_vel
            if i < 2:
                self.rectangles[i].x -= 1
            else:
                self.rectangles[i].x += 1

        if self.rectangles[1].y > core.get_map().mapSize[1] * 32:
            core.get_map().debris.remove(self)

    def render(self, core):
        for rect in self.rectangles:
            self.rect = rect
            core.screen.blit(self.image, core.get_map().get_camera().apply(self))

class Player(object):
    def __init__(self, x_pos, y_pos):
        self.numOfLives = 3
        self.score = 0
        self.coins = 0

        self.visible = True
        self.spriteTick = 0
        self.powerLVL = 0

        self.unkillable = False
        self.unkillableTime = 0

        self.inLevelUpAnimation = False
        self.inLevelUpAnimationTime = 0
        self.inLevelDownAnimation = False
        self.inLevelDownAnimationTime = 0

        self.already_jumped = False
        self.next_jump_time = 0
        self.next_fireball_time = 0
        self.x_vel = 0
        self.y_vel = 0
        self.direction = True
        self.on_ground = False
        self.fast_moving = False
        
        self.pos_x = x_pos

        self.image = pg.image.load('images/mario/mario.png').convert_alpha()
        self.sprites = []
        self.load_sprites()

        self.rect = pg.Rect(x_pos, y_pos, 32, 32)

    def load_sprites(self):
        self.sprites = [
            # 0 Small, stay
            pg.image.load('images/Mario/mario.png'),

            # 1 Small, move 0
            pg.image.load('images/Mario/mario_move0.png'),

            # 2 Small, move 1
            pg.image.load('images/Mario/mario_move1.png'),

            # 3 Small, move 2
            pg.image.load('images/Mario/mario_move2.png'),

            # 4 Small, jump
            pg.image.load('images/Mario/mario_jump.png'),

            # 5 Small, end 0
            pg.image.load('images/Mario/mario_end.png'),

            # 6 Small, end 1
            pg.image.load('images/Mario/mario_end1.png'),

            # 7 Small, stop
            pg.image.load('images/Mario/mario_st.png'),

            # =============================================

            # 8 Big, stay
            pg.image.load('images/Mario/mario1.png'),

            # 9 Big, move 0
            pg.image.load('images/Mario/mario1_move0.png'),

            # 10 Big, move 1
            pg.image.load('images/Mario/mario1_move1.png'),

            # 11 Big, move 2
            pg.image.load('images/Mario/mario1_move2.png'),

            # 12 Big, jump
            pg.image.load('images/Mario/mario1_jump.png'),

            # 13 Big, end 0
            pg.image.load('images/Mario/mario1_end.png'),

            # 14 Big, end 1
            pg.image.load('images/Mario/mario1_end1.png'),

            # 15 Big, stop
            pg.image.load('images/Mario/mario1_st.png'),

            # =============================================

            # 16 Big_fireball, stay
            pg.image.load('images/Mario/mario2.png'),

            # 17 Big_fireball, move 0
            pg.image.load('images/Mario/mario2_move0.png'),

            # 18 Big_fireball, move 1
            pg.image.load('images/Mario/mario2_move1.png'),

            # 19 Big_fireball, move 2
            pg.image.load('images/Mario/mario2_move2.png'),

            # 20 Big_fireball, jump
            pg.image.load('images/Mario/mario2_jump.png'),

            # 21 Big_fireball, end 0
            pg.image.load('images/Mario/mario2_end.png'),

            # 22 Big_fireball, end 1
            pg.image.load('images/Mario/mario2_end1.png'),

            # 23 Big_fireball, stop
            pg.image.load('images/Mario/mario2_st.png'),
        ]

        # Left side
        for i in range(len(self.sprites)):
            self.sprites.append(pg.transform.flip(self.sprites[i], 180, 0))

        # Power level changing, right
        self.sprites.append(pg.image.load('images/Mario/mario_lvlup.png').convert_alpha())

        # Power level changing, left
        self.sprites.append(pg.transform.flip(self.sprites[-1], 180, 0))

        # Death
        self.sprites.append(pg.image.load('images/Mario/mario_death.png').convert_alpha())

    def update(self, core):
        self.player_physics(core)
        self.update_image(core)
        self.update_unkillable_time()

    def player_physics(self, core):
        if core.keyR:
            self.x_vel += SPEED_INCREASE_RATE
            self.direction = True
        if core.keyL:
            self.x_vel -= SPEED_INCREASE_RATE
            self.direction = False
        if not core.keyU:
            self.already_jumped = False
        elif core.keyU:
            if self.on_ground and not self.already_jumped:
                self.y_vel = -JUMP_POWER
                self.already_jumped = True
                self.next_jump_time = pg.time.get_ticks() + 750
                if self.powerLVL >= 1:
                    core.get_sound().play('big_mario_jump', 0, 0.5)
                else:
                    core.get_sound().play('small_mario_jump', 0, 0.5)

        # Fireball shoot and fast moving
        self.fast_moving = False
        if core.keyShift:
            self.fast_moving = True
            if self.powerLVL == 2:
                if pg.time.get_ticks() > self.next_fireball_time:
                    if not (self.inLevelUpAnimation or self.inLevelDownAnimation):
                        if len(core.get_map().projectiles) < 2:
                            self.shoot_fireball(core, self.rect.x, self.rect.y, self.direction)

        if not (core.keyR or core.keyL):
            if self.x_vel > 0:
                self.x_vel -= SPEED_DECREASE_RATE
            elif self.x_vel < 0:
                self.x_vel += SPEED_DECREASE_RATE
        else:
            if self.x_vel > 0:
                if self.fast_moving:
                    if self.x_vel > MAX_FASTMOVE_SPEED:
                        self.x_vel = MAX_FASTMOVE_SPEED
                else:
                    if self.x_vel > MAX_MOVE_SPEED:
                        self.x_vel = MAX_MOVE_SPEED
            if self.x_vel < 0:
                if self.fast_moving:
                    if (-self.x_vel) > MAX_FASTMOVE_SPEED: self.x_vel = -MAX_FASTMOVE_SPEED
                else:
                    if (-self.x_vel) > MAX_MOVE_SPEED:
                        self.x_vel = -MAX_MOVE_SPEED

        # removing the computational error
        if 0 < self.x_vel < SPEED_DECREASE_RATE:
            self.x_vel = 0
        if 0 > self.x_vel > -SPEED_DECREASE_RATE:
            self.x_vel = 0

        if not self.on_ground:
            # Moving up, button is pressed
            if (self.y_vel < 0 and core.keyU):
                self.y_vel += GRAVITY
                
            # Moving up, button is not pressed - low jump
            elif (self.y_vel < 0 and not core.keyU):
                self.y_vel += GRAVITY * LOW_JUMP_MULTIPLIER
            
            # Moving down
            else:
                self.y_vel += GRAVITY * FALL_MULTIPLIER
            
            if self.y_vel > MAX_FALL_SPEED:
                self.y_vel = MAX_FALL_SPEED

        blocks = core.get_map().get_blocks_for_collision(self.rect.x // 32, self.rect.y // 32)
        
        self.pos_x += self.x_vel
        self.rect.x = self.pos_x
        
        self.update_x_pos(blocks)

        self.rect.y += self.y_vel
        self.update_y_pos(blocks, core)

        # on_ground parameter won't be stable without this piece of code
        coord_y = self.rect.y // 32
        if self.powerLVL > 0:
            coord_y += 1
        for block in core.get_map().get_blocks_below(self.rect.x // 32, coord_y):
            if block != 0 and block.type != 'BGObject':
                if pg.Rect(self.rect.x, self.rect.y + 1, self.rect.w, self.rect.h).colliderect(block.rect):
                    self.on_ground = True

        # Map border check
        if self.rect.y > 448:
            core.get_map().player_death(core)

        # End Flag collision check
        if self.rect.colliderect(core.get_map().flag.pillar_rect):
            core.get_map().player_win(core)

    def set_image(self, image_id):

        # "Dead" sprite
        if image_id == len(self.sprites):
            self.image = self.sprites[-1]

        elif self.direction:
            self.image = self.sprites[image_id + self.powerLVL * 8]
        else:
            self.image = self.sprites[image_id + self.powerLVL * 8 + 24]

    def update_image(self, core):

        self.spriteTick += 1
        if (core.keyShift):
            self.spriteTick += 1

        if self.powerLVL in (0, 1, 2):

            if self.x_vel == 0:
                self.set_image(0)
                self.spriteTick = 0

            # Player is running
            elif (
                    ((self.x_vel > 0 and core.keyR and not core.keyL) or
                     (self.x_vel < 0 and core.keyL and not core.keyR)) or
                    (self.x_vel > 0 and not (core.keyL or core.keyR)) or
                    (self.x_vel < 0 and not (core.keyL or core.keyR))
            ):
                             
                if (self.spriteTick > 30):
                    self.spriteTick = 0
                   
                if self.spriteTick <= 10:
                    self.set_image(1)
                elif 11 <= self.spriteTick <= 20:
                    self.set_image(2)
                elif 21 <= self.spriteTick <= 30:
                    self.set_image(3)
                elif self.spriteTick == 31:
                    self.spriteTick = 0
                    self.set_image(1)

            # Player decided to move in the another direction, but hasn't stopped yet
            elif (self.x_vel > 0 and core.keyL and not core.keyR) or (self.x_vel < 0 and core.keyR and not core.keyL):
                self.set_image(7)
                self.spriteTick = 0

            if not self.on_ground:
                self.spriteTick = 0
                self.set_image(4)

    def update_unkillable_time(self):
        if self.unkillable:
            self.unkillableTime -= 1
            if self.unkillableTime == 0:
                self.unkillable = False

    def update_x_pos(self, blocks):
        for block in blocks:
            if block != 0 and block.type != 'BGObject':
                block.debugLight = True
                if pg.Rect.colliderect(self.rect, block.rect):
                    if self.x_vel > 0:
                        self.rect.right = block.rect.left
                        self.pos_x = self.rect.left
                        self.x_vel = 0
                    elif self.x_vel < 0:
                        self.rect.left = block.rect.right
                        self.pos_x = self.rect.left
                        self.x_vel = 0

    def update_y_pos(self, blocks, core):
        self.on_ground = False
        for block in blocks:
            if block != 0 and block.type != 'BGObject':
                if pg.Rect.colliderect(self.rect, block.rect):

                    if self.y_vel > 0:
                        self.on_ground = True
                        self.rect.bottom = block.rect.top
                        self.y_vel = 0

                    elif self.y_vel < 0:
                        self.rect.top = block.rect.bottom
                        self.y_vel = -self.y_vel / 3
                        self.activate_block_action(core, block)

    def activate_block_action(self, core, block):
        # Question Block
        if block.typeID == 22:
            core.get_sound().play('block_hit', 0, 0.5)
            if not block.isActivated:
                block.spawn_bonus(core)

        # Brick Platform
        elif block.typeID == 23:
            if self.powerLVL == 0:
                block.shaking = True
                core.get_sound().play('block_hit', 0, 0.5)
            else:
                block.destroy(core)
                core.get_sound().play('brick_break', 0, 0.5)
                self.add_score(50)

    def reset(self, reset_all):
        self.direction = True
        self.rect.x = 96
        self.pos_x = 96
        self.rect.y = 351
        if self.powerLVL != 0:
            self.powerLVL = 0
            self.rect.y += 32
            self.rect.h = 32

        if reset_all:
            self.score = 0
            self.coins = 0
            self.numOfLives = 3

            self.visible = True
            self.spriteTick = 0
            self.powerLVL = 0
            self.inLevelUpAnimation = False
            self.inLevelUpAnimationTime = 0

            self.unkillable = False
            self.unkillableTime = 0

            self.inLevelDownAnimation = False
            self.inLevelDownAnimationTime = 0

            self.already_jumped = False
            self.x_vel = 0
            self.y_vel = 0
            self.on_ground = False

    def reset_jump(self):
        self.y_vel = 0
        self.already_jumped = False

    def reset_move(self):
        self.x_vel = 0
        self.y_vel = 0

    def jump_on_mob(self):
        self.already_jumped = True
        self.y_vel = -4
        self.rect.y -= 6

    def set_powerlvl(self, power_lvl, core):
        if self.powerLVL == 0 == power_lvl and not self.unkillable:
            core.get_map().player_death(core)
            self.inLevelUpAnimation = False
            self.inLevelDownAnimation = False

        elif self.powerLVL == 0 and self.powerLVL < power_lvl:
            self.powerLVL = 1
            core.get_sound().play('mushroom_eat', 0, 0.5)
            core.get_map().spawn_score_text(self.rect.x + 16, self.rect.y, score=1000)
            self.add_score(1000)
            self.inLevelUpAnimation = True
            self.inLevelUpAnimationTime = 61

        elif self.powerLVL == 1 and self.powerLVL < power_lvl:
            core.get_sound().play('mushroom_eat', 0, 0.5)
            core.get_map().spawn_score_text(self.rect.x + 16, self.rect.y, score=1000)
            self.add_score(1000)
            self.powerLVL = 2

        elif self.powerLVL > power_lvl:
            core.get_sound().play('pipe', 0, 0.5)
            self.inLevelDownAnimation = True
            self.inLevelDownAnimationTime = 200
            self.unkillable = True
            self.unkillableTime = 200

        else:
            core.get_sound().play('mushroom_eat', 0, 0.5)
            core.get_map().spawn_score_text(self.rect.x + 16, self.rect.y, score=1000)
            self.add_score(1000)

    def change_powerlvl_animation(self):

        if self.inLevelDownAnimation:
            self.inLevelDownAnimationTime -= 1

            if self.inLevelDownAnimationTime == 0:
                self.inLevelDownAnimation = False
                self.visible = True
            elif self.inLevelDownAnimationTime % 20 == 0:
                if self.visible:
                    self.visible = False
                else:
                    self.visible = True
                if self.inLevelDownAnimationTime == 100:
                    self.powerLVL = 0
                    self.rect.y += 32
                    self.rect.h = 32

        elif self.inLevelUpAnimation:
            self.inLevelUpAnimationTime -= 1

            if self.inLevelUpAnimationTime == 0:
                self.inLevelUpAnimation = False
                self.rect.y -= 32
                self.rect.h = 64

            elif self.inLevelUpAnimationTime in (60, 30):
                self.image = self.sprites[-3] if self.direction else self.sprites[-2]
                self.rect.y -= 16
                self.rect.h = 48

            elif self.inLevelUpAnimationTime in (45, 15):
                self.image = self.sprites[0] if self.direction else self.sprites[24]
                self.rect.y += 16
                self.rect.h = 32

    def flag_animation_move(self, core, walk_to_castle):
        if walk_to_castle:
            self.direction = True

            if not self.on_ground:
                self.y_vel += GRAVITY if self.y_vel <= MAX_FALL_SPEED else 0

            x = self.rect.x // 32
            y = self.rect.y // 32
            blocks = core.get_map().get_blocks_for_collision(x, y)

            self.rect.x += self.x_vel
            if self.rect.colliderect(core.get_map().map[205][11]):
                self.visible = False
                core.get_map().get_event().player_in_castle = True
            self.update_x_pos(blocks)

            self.rect.top += self.y_vel
            self.update_y_pos(blocks, core)

            # on_ground works incorrect without this piece of code
            x = self.rect.x // 32
            y = self.rect.y // 32
            if self.powerLVL > 0:
                y += 1
            for block in core.get_map().get_blocks_below(x, y):
                if block != 0 and block.type != 'BGObject':
                    if pg.Rect(self.rect.x, self.rect.y + 1, self.rect.w, self.rect.h).colliderect(block.rect):
                        self.on_ground = True

        else:
            if core.get_map().flag.flag_rect.y + 20 > self.rect.y + self.rect.h:
                self.rect.y += 3

    def shoot_fireball(self, core, x, y, move_direction):
        core.get_map().spawn_fireball(x, y, move_direction)
        core.get_sound().play('fireball', 0, 0.5)
        self.next_fireball_time = pg.time.get_ticks() + 400

    def add_coins(self, count):
        self.coins += count

    def add_score(self, count):
        self.score += count

    def render(self, core):
        if self.visible:
            core.screen.blit(self.image, core.get_map().get_camera().apply(self))

class Sound(object):
    def __init__(self):
        self.sounds = {}
        self.load_sounds()

    def load_sounds(self):
        self.sounds['overworld'] = pg.mixer.Sound('sounds/overworld.wav')
        self.sounds['overworld_fast'] = pg.mixer.Sound('sounds/overworld-fast.wav')
        self.sounds['level_end'] = pg.mixer.Sound('sounds/levelend.wav')
        self.sounds['coin'] = pg.mixer.Sound('sounds/coin.wav')
        self.sounds['small_mario_jump'] = pg.mixer.Sound('sounds/jump.wav')
        self.sounds['big_mario_jump'] = pg.mixer.Sound('sounds/jumpbig.wav')
        self.sounds['brick_break'] = pg.mixer.Sound('sounds/blockbreak.wav')
        self.sounds['block_hit'] = pg.mixer.Sound('sounds/blockhit.wav')
        self.sounds['mushroom_appear'] = pg.mixer.Sound('sounds/mushroomappear.wav')
        self.sounds['mushroom_eat'] = pg.mixer.Sound('sounds/mushroomeat.wav')
        self.sounds['death'] = pg.mixer.Sound('sounds/death.wav')
        self.sounds['pipe'] = pg.mixer.Sound('sounds/pipe.wav')
        self.sounds['kill_mob'] = pg.mixer.Sound('sounds/kill_mob.wav')
        self.sounds['game_over'] = pg.mixer.Sound('sounds/gameover.wav')
        self.sounds['scorering'] = pg.mixer.Sound('sounds/scorering.wav')
        self.sounds['fireball'] = pg.mixer.Sound('sounds/fireball.wav')
        self.sounds['shot'] = pg.mixer.Sound('sounds/shot.wav')

    def play(self, name, loops, volume):
        self.sounds[name].play(loops=loops)
        self.sounds[name].set_volume(volume)

    def stop(self, name):
        self.sounds[name].stop()

    def start_fast_music(self, core):
        if core.get_map().get_name() == '1-1':
            self.stop('overworld')
            self.play('overworld_fast', 99999, 0.5)

class Text(object):
    def __init__(self, text, fontsize, rectcenter, font='Emulogic', textcolor = (255, 255, 255)):
        self.font = pg.font.Font('fonts/emulogic.ttf', fontsize)
        self.text = self.font.render(text, False, textcolor)
        self.rect = self.text.get_rect(center=rectcenter)
        self.y_offset = 0

    def update(self, core):
        self.rect.y -= 1
        self.y_offset -= 1

        if self.y_offset == -100:
            core.get_map().remove_text(self)

    def render(self, core):
        core.screen.blit(self.text, self.rect)

    def render_in_game(self, core):
        core.screen.blit(self.text, core.get_map().get_camera().apply(self))

class Tube(pg.sprite.Sprite):
    def __init__(self, x_pos, y_pos):
        super().__init__()
        self.image = pg.image.load('images/tube.png').convert_alpha()
        length = (12 - y_pos) * 32
        self.image = self.image.subsurface(0, 0, 64, length)
        self.rect = pg.Rect(x_pos * 32, y_pos * 32, 64, length)

    def render(self, core):
        core.screen.blit(self.image, core.get_map().get_camera().apply(self))

if __name__ == '__main__':
    oCore = Core()
    oCore.main_loop()
